#####################################################################
# ADOBE CONFIDENTIAL
# ___________________
#
#  Copyright 2018 Adobe
#  All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains
# the property of Adobe and its suppliers, if any. The intellectual
# and technical concepts contained herein are proprietary to Adobe
# and its suppliers and are protected by all applicable intellectual
# property laws, including trade secret and copyright laws.
# Dissemination of this information or reproduction of this material
# is strictly forbidden unless prior written permission is obtained
# from Adobe.
#####################################################################

from ml.runtime.python.Interfaces.AbstractScorer import AbstractScorer
import tensorflow as tf
import numpy


class Scorer(AbstractScorer):
    def score(self, config={}):
        print("Executed scorer 2")
        print(config["modelPATH"])
        print(config["logsPATH"])
        with tf.Session() as sess:
            saver = tf.train.import_meta_graph(config["modelPATH"]+'/my_test_model-1000.meta')
            saver.restore(sess, tf.train.latest_checkpoint(config["modelPATH"]+'/'))
            graph = tf.get_default_graph()
            # Testing example, as requested (Issue #2)
            test_X = numpy.asarray([6.83, 4.668, 8.9, 7.91, 5.7, 8.7, 3.1, 2.1])
            X = tf.placeholder("float")
            W = graph.get_tensor_by_name("weight:0")
            b = graph.get_tensor_by_name("bias:0")
            pred = tf.add(tf.multiply(X, W), b)
            p = sess.run(pred,feed_dict={X:test_X})
            print(p)
